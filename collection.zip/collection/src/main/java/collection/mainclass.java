package collection;

import java.util.Scanner;

public class mainclass {

	public static void main(String args[])
	{
		ArraylistClass obj=new ArraylistClass();
		Scanner sn=new Scanner(System.in);
		int e,ch=0,c=1;
		do
		{
			System.out.println("Main Menu");
        	System.out.println("1. Add an element");
        	System.out.println("2. Remove an element");
        	System.out.println("3. Fetch index of an element");
        	System.out.println("4. Get element by index");
        	System.out.println("5. Display the list");
        	System.out.println("Enter your choice: ");
        	
        	ch = sn.nextInt();
        	
        	switch(ch) {
        	case 1: System.out.println("\nEnter the element to be added: ");
        			e = sn.nextInt();
        			obj.addEle(e);
        		    break;
        	case 2: System.out.println("\nEnter the element to be removed: ");
					e = sn.nextInt();
					obj.delEle(e);
					break;
			case 3: System.out.println("\nEnter the element to be searched: ");
					e = sn.nextInt();
					System.out.println("\nThe index of "+e+" is: "+obj.getIndex(e));
					break;
			case 4: System.out.println("\nEnter the index to be searched: ");
			         e=sn.nextInt();
			         System.out.println("The element is:"+obj.getelement(e));
			         break;
			case 5: obj.disp();
					break;
			default: System.out.println("Wrong choice.");
    	}
        	
        	System.out.println("Enter 0 to exit and 1 to continue): ");
        	c = sn.nextInt();     
		}while(c==1);
		System.out.print("End");
		
		
	}
}

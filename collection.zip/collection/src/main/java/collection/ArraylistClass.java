package collection;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ArraylistClass{

	List<Integer> list=new ArrayList<>();
	Scanner sn=new Scanner(System.in);
	int a;
	ArraylistClass()
	{
		System.out.println("Enter 10 numbers:");
		for(int i=0;i<10;i++)
		{
			a=sn.nextInt();
			 
			list.add(a);
		}
	}
	
	void addEle(int a)
	{
		list.add(a);
		System.out.println("added "+a+"to list");
	}
	
	void delEle(int a)
	{
		list.remove(a);
		System.out.println("deleted "+a+" from the list");
	}
	
	int getIndex(int ele)
	{
		return (list.indexOf(ele));
	}
	
	int getelement(int a)
	{
		return list.get(a);
	}
	
	void disp()
	{
		System.out.println("The list is:");
		System.out.print(list);
	/*	for(int i=0;i<list.size();i++)
		{
			System.out.print(list.get(i)+" ");
			
		}*/
		System.out.println();
	}
}
